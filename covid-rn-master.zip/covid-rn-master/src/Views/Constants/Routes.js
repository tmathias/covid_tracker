const ButtomTabs = {
  Overview: 'Overview',
  Countries: 'Countries',
  Analytics: 'Analytics',
  HeatMap: 'Heat Map',
  //Reddit: 'Reddit',
  Twitter: 'Twitter',
};

export {ButtomTabs};
