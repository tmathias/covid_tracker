export {AnimatedTabBar as default} from './AnimatedTabBar';
